/*
 * protocol.h
 *
 *  Created on: 22 nov 2022
 *      Author: simone Lotito, MArco Garofalo
 */


#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#define PROTO_PORT 60000
#define BUFFER_SIZE 128
#define QLEN 5
#define NO_ERROR 0

typedef struct {
	char operand;
	int number1;
	int number2;
} msg;

typedef struct {
	int result;
} res;

void flush () {
	while (getchar() != '\n'){
		;
	}
}

 void operate (msg *math, char op, int n1, int n2) {
	math->operand = op;
	math->number1 = n1;
	math->number2 = n2;
}

#endif /* PROTOCOL_H_ */
