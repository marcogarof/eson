/*
 ============================================================================
 Name        : Client_esonero.c
 Author      : Simone Lotito, Marco Garofalo
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif

#include <stdio.h>
#include "protocol.h"

void clearwinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

void errorhandler(char *errorMessage) {
	printf("%s", errorMessage);
}

int main(int argc, char *argv[]) {
#if defined WIN32
	// Initialize Winsock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2,2), &wsa_data);
	if (result != NO_ERROR) {
		printf("Error at WSAStartup()\n");
		return 0;
	}
#endif

	// create client socket
	int c_socket;
	c_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (c_socket < 0) {
		errorhandler("socket creation failed.\n");
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}

	// set connection settings
	struct sockaddr_in sad;
	memset(&sad, 0, sizeof(sad));
	sad.sin_family = AF_INET;
	sad.sin_addr.s_addr = inet_addr("127.0.0.1"); // IP del server
	sad.sin_port = htons(PROTO_PORT); // Server port

	// connection
	if (connect(c_socket, (struct sockaddr*) &sad, sizeof(sad)) < 0) {
		errorhandler("Failed to connect.\n");
		system ("PAUSE");
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}


	// get data from user
	char operation = ' ';
	int n1, n2;

	printf("Enter the operand followed by two numbers: \n");
	msg m;
	scanf("%c%d%d",&operation, &n1,&n2);
	flush ();
	operate (&m, operation, n1, n2);
	if (send(c_socket, &m, sizeof(msg), 0) != sizeof(msg)) {
		errorhandler("send() sent a different number of bytes than expected");
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}
	while (operation != '=') {
		// get reply from server
		res result;
		if ((recv(c_socket, &result, sizeof(res), 0)) <= 0) {
			errorhandler("recv() failed or connection closed prematurely");
			closesocket(c_socket);
			clearwinsock();
			return -1;
		}
		//print result and get data from user
		printf("%d %c %d = %d\n", m.number1, m.operand, m.number2, result.result);
		printf("Enter the operand followed by two numbers: \n");
		operation = getchar();
		scanf("%d%d", &n1,&n2);
		flush ();
		//repeat until operand is =
		operate (&m, operation, n1, n2);
		if (send(c_socket, &m, sizeof(msg), 0) != sizeof(msg)) {
			errorhandler("send() sent a different number of bytes than expected");
			closesocket(c_socket);
			clearwinsock();
			return -1;
		}
	};

	system("PAUSE");
	closesocket(c_socket);
	clearwinsock();
	return 0;
} // main end
